# Painel de Controle de Tarefas

Projeto da atividade de Python/Flask.

## Importante

Esta versão NÃO usa:
- JavaScript
- Werkzeug diretamente
- Chart.js

Usa somente:
- Python
- Flask
- SQLite
- Requests
- HTML
- CSS
- Bootstrap

## Recursos da atividade

1. Rotas e templates
2. Banco SQLite
3. Cadastro, login e logout
4. Sessão para proteger páginas internas
5. CRUD completo de tarefas
6. Bootstrap e ícones
7. API externa de frase motivacional
8. Filtro por status sem JavaScript
9. Modo visual simples com CSS
10. Página de progresso usando barras do Bootstrap
11. SECRET_KEY
12. DEBUG para desenvolvimento

## Como executar

Abra a pasta no VS Code.

No terminal:

python -m venv venv

No Windows:

venv\Scripts\activate

Depois:

pip install -r requirements.txt

Execute:

python app.py

Abra:

http://127.0.0.1:5000

O arquivo tarefas.db será criado automaticamente.
