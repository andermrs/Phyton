from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import requests
import hashlib
import secrets
from functools import wraps

app = Flask(__name__)
app.config["SECRET_KEY"] = "chave-secreta-do-projeto"
DATABASE = "tarefas.db"


def conectar():
    banco = sqlite3.connect(DATABASE)
    banco.row_factory = sqlite3.Row
    return banco


def criar_banco():
    banco = conectar()

    banco.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            senha TEXT NOT NULL
        )
    """)

    banco.execute("""
        CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descricao TEXT,
            status TEXT NOT NULL DEFAULT 'Pendente',
            usuario_id INTEGER NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    """)

    banco.commit()
    banco.close()

def criar_senha(senha):
    salt = secrets.token_hex(16)
    hash_senha = hashlib.sha256((salt + senha).encode()).hexdigest()
    return salt + ":" + hash_senha


def conferir_senha(senha, senha_salva):
    try:
        salt, hash_salvo = senha_salva.split(":")
        hash_novo = hashlib.sha256((salt + senha).encode()).hexdigest()
        return secrets.compare_digest(hash_novo, hash_salvo)
    except ValueError:
        return False


def login_obrigatorio(funcao):
    @wraps(funcao)
    def verificar(*args, **kwargs):
        if "usuario_id" not in session:
            return redirect(url_for("login"))
        return funcao(*args, **kwargs)

    return verificar


@app.route("/")
def inicio():
    if "usuario_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nome = request.form["nome"].strip()
        email = request.form["email"].strip().lower()
        senha = request.form["senha"]

        if not nome or not email or not senha:
            flash("Preencha todos os campos.")
            return redirect(url_for("registro"))

        banco = conectar()

        try:
            banco.execute(
                "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)",
                (nome, email, criar_senha(senha))
            )
            banco.commit()
        except sqlite3.IntegrityError:
            banco.close()
            flash("Este e-mail já está cadastrado.")
            return redirect(url_for("registro"))

        banco.close()

        flash("Cadastro realizado com sucesso!")
        return redirect(url_for("login"))

    return render_template("registro.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        senha = request.form["senha"]

        banco = conectar()
        usuario = banco.execute(
            "SELECT * FROM usuarios WHERE email = ?",
            (email,)
        ).fetchone()
        banco.close()

        if usuario and conferir_senha(senha, usuario["senha"]):
            session["usuario_id"] = usuario["id"]
            session["usuario_nome"] = usuario["nome"]
            return redirect(url_for("dashboard"))

        flash("E-mail ou senha incorretos.")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_obrigatorio
def dashboard():
    filtro = request.args.get("status", "Todos")

    banco = conectar()

    if filtro in ["Pendente", "Em andamento", "Concluída"]:
        tarefas = banco.execute(
            """SELECT * FROM tarefas
               WHERE usuario_id = ? AND status = ?
               ORDER BY id DESC""",
            (session["usuario_id"], filtro)
        ).fetchall()
    else:
        tarefas = banco.execute(
            """SELECT * FROM tarefas
               WHERE usuario_id = ?
               ORDER BY id DESC""",
            (session["usuario_id"],)
        ).fetchall()

    banco.close()

    frase = "TRABALHO DO ANDRÉ"

    try:
        resposta = requests.get(
            "https://api.adviceslip.com/advice",
            timeout=3
        )

        if resposta.ok:
            frase = resposta.json()["slip"]["advice"]
    except requests.RequestException:
        pass

    return render_template(
        "dashboard.html",
        tarefas=tarefas,
        frase=frase,
        filtro=filtro
    )


@app.route("/nova_tarefa", methods=["GET", "POST"])
@login_obrigatorio
def nova_tarefa():
    if request.method == "POST":
        titulo = request.form["titulo"].strip()
        descricao = request.form["descricao"].strip()
        status = request.form["status"]

        if not titulo:
            flash("O título é obrigatório.")
            return redirect(url_for("nova_tarefa"))

        banco = conectar()

        banco.execute(
            """INSERT INTO tarefas
               (titulo, descricao, status, usuario_id)
               VALUES (?, ?, ?, ?)""",
            (titulo, descricao, status, session["usuario_id"])
        )

        banco.commit()
        banco.close()

        flash("Tarefa criada com sucesso!")
        return redirect(url_for("dashboard"))

    return render_template("nova_tarefa.html")


@app.route("/editar/<int:id>", methods=["GET", "POST"])
@login_obrigatorio
def editar(id):
    banco = conectar()

    tarefa = banco.execute(
        """SELECT * FROM tarefas
           WHERE id = ? AND usuario_id = ?""",
        (id, session["usuario_id"])
    ).fetchone()

    if not tarefa:
        banco.close()
        return "Tarefa não encontrada.", 404

    if request.method == "POST":
        titulo = request.form["titulo"].strip()
        descricao = request.form["descricao"].strip()
        status = request.form["status"]

        if not titulo:
            banco.close()
            flash("O título é obrigatório.")
            return redirect(url_for("editar", id=id))

        banco.execute(
            """UPDATE tarefas
               SET titulo = ?, descricao = ?, status = ?
               WHERE id = ? AND usuario_id = ?""",
            (titulo, descricao, status, id, session["usuario_id"])
        )

        banco.commit()
        banco.close()

        flash("Tarefa atualizada!")
        return redirect(url_for("dashboard"))

    banco.close()
    return render_template("editar.html", tarefa=tarefa)


@app.route("/excluir/<int:id>")
@login_obrigatorio
def excluir(id):
    banco = conectar()

    banco.execute(
        """DELETE FROM tarefas
           WHERE id = ? AND usuario_id = ?""",
        (id, session["usuario_id"])
    )

    banco.commit()
    banco.close()

    flash("Tarefa excluída.")
    return redirect(url_for("dashboard"))


@app.route("/concluir/<int:id>")
@login_obrigatorio
def concluir(id):
    banco = conectar()

    banco.execute(
        """UPDATE tarefas
           SET status = 'Concluída'
           WHERE id = ? AND usuario_id = ?""",
        (id, session["usuario_id"])
    )

    banco.commit()
    banco.close()

    return redirect(url_for("dashboard"))


@app.route("/progresso")
@login_obrigatorio
def progresso():
    banco = conectar()

    tarefas = banco.execute(
        """SELECT status, COUNT(*) AS quantidade
           FROM tarefas
           WHERE usuario_id = ?
           GROUP BY status""",
        (session["usuario_id"],)
    ).fetchall()

    banco.close()

    dados = {
        "Pendente": 0,
        "Em andamento": 0,
        "Concluída": 0
    }

    for tarefa in tarefas:
        dados[tarefa["status"]] = tarefa["quantidade"]

    total = sum(dados.values())

    porcentagens = {}

    for status, quantidade in dados.items():
        if total > 0:
            porcentagens[status] = round(quantidade / total * 100)
        else:
            porcentagens[status] = 0

    return render_template(
        "progresso.html",
        dados=dados,
        porcentagens=porcentagens
    )


if __name__ == "__main__":
    criar_banco()
    app.run(debug=True)
